# Copyright (C) 2010-2017 - Andreas Maier 
# CONRAD is developed as an Open Source project under the GNU General Public License (GPL-3.0)

import numpy
java_float_dtype = numpy.dtype(">f4")
