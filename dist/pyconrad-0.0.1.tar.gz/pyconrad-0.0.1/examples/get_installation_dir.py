
# Copyright (C) 2010-2017 - Andreas Maier
# CONRAD is developed as an Open Source project under the GNU General Public License (GPL-3.0)

import pyconrad_java

print("CONRAD installation directory is:")
print(pyconrad_java.conrad_jar_dir)
